package jingganban;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
public class UsersCl extends HttpServlet {


	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String flag=req.getParameter("flag");
		UserBeanCl ubc=new UserBeanCl();
		if(flag.equals("addUser")){		//�����û�
			
				String number=req.getParameter("number");
				String name=new String(req.getParameter("name").getBytes("iso-8859-1"),"utf-8");
				String passwd=req.getParameter("password");
				String QQ=req.getParameter("QQ");
				String phone=req.getParameter("phone");
				String group=new String(req.getParameter("group").getBytes("iso-8859-1"),"utf-8");
				String grand=req.getParameter("grade");
				
				if(ubc.addUser(number, name, passwd,QQ,phone,group,grand)){
					req.getRequestDispatcher("Suc.jsp").forward(req,res);//	
				}
				else{
					req.getRequestDispatcher("Err.jsp").forward(req,res);//
					}	
		}
		else if(flag.equals("fenye")){
			String s_pageNow=req.getParameter("pageNow");
			try{
				int pageNow=Integer.parseInt(s_pageNow);
				
				ArrayList<UserBean> al=ubc.getUsersByPage(pageNow);
				int pageCount=ubc.getPageCount();
				req.setAttribute("result", al);
				req.setAttribute("pageCount", pageCount+"");
				req.setAttribute("pageNow",pageNow+"");
				//������ת��������
				req.getRequestDispatcher("MangerUsers.jsp").forward(req,res);
			 
			}catch(Exception e){
			e.printStackTrace();
			}
		}
		else if(flag.equals("updataUser")){
			//��Ӧ�޸����󣬲�ѯ��ϸ��ϢȻ����ת������ҳ��
			String number="number="+req.getParameter("userId");
			ArrayList<UserBean> all=ubc.seek(number,1);
			//UserBean al=ubc.seek( number);
			UserBean al=all.get(0);
			//System.out.println(al.getPasswd());
			req.setAttribute("result", al);	
			req.getRequestDispatcher("UpdataUser.jsp?").forward(req,res);
		}
		else if(flag.equals("updataUserCl")){
			//�����޸����󣬵���UserBeanCl�����ݿ��޸�
			String number=req.getParameter("number");
			String name=new String(req.getParameter("name").getBytes("iso-8859-1"),"utf-8");
			String passwd=req.getParameter("password");
			String QQ=req.getParameter("QQ");
			String phone=req.getParameter("phone");
			String group=new String(req.getParameter("group").getBytes("iso-8859-1"),"utf-8");
			String grand=req.getParameter("grade");
			if(ubc.updadaUser(number, name, passwd,QQ,phone,group,grand)){
				req.getRequestDispatcher("Suc.jsp").forward(req,res);//	
				
				
				//System.out.println("123");
			}
			else{
				req.getRequestDispatcher("Err.jsp").forward(req,res);//
				
				//System.out.println("shibai");
				}	
		}
		else if(flag.equals("passwdUpdate")){//�޸�����
			HttpSession session=req.getSession();
			String number=(String)session.getAttribute("number");
			String passwd=req.getParameter("password");
			String passwdNew=req.getParameter("passwordNew");
			if(ubc.checkUser(number, passwd)!=0){
				if(ubc.passwdUpdate(number, passwdNew)){
					req.getRequestDispatcher("Suc.jsp").forward(req,res);
				}
				else{req.getRequestDispatcher("Err.jsp").forward(req,res);
				}
			}
			else{req.getRequestDispatcher("Err.jsp").forward(req,res);
			}
		}
		else if(flag.equals("delUser")){
			//ɾ���û�
			String userId=req.getParameter("userId");
			if(ubc.delUserById(userId)){
				req.getRequestDispatcher("Suc.jsp").forward(req,res);//ɾ���ɹ�
			}
			else{
				req.getRequestDispatcher("Err.jsp").forward(req,res);//ɾ��ʧ��
			}
		}
		else if(flag.equals("seek")){
			//��ѯ
			//String name=new String(req.getParameter("name").getBytes("iso-8859-1"),"utf-8");
			String flagCx=req.getParameter("flagCx");
			String selectCx= flagCx+"= '"+new String(req.getParameter("select").getBytes("iso-8859-1"),"utf-8")+"'";
			
					//req.getParameter("select");		
			String s_pageNow=req.getParameter("pageNow");
			try{
				int pageNow=Integer.parseInt(s_pageNow);			
				ArrayList<UserBean> al=ubc.seek(selectCx,pageNow);
				int pageCount=ubc.getPageCount();
				req.setAttribute("result", al);
				req.setAttribute("pageCount", pageCount+"");
				req.setAttribute("pageNow",pageNow+"");
				//������ת��������
				req.getRequestDispatcher("SeekShow.jsp").forward(req,res);
			 
			}catch(Exception e){
			e.printStackTrace();
			}
				
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

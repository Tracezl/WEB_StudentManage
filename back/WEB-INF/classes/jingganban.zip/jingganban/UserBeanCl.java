package jingganban;

import java.sql.*;
import java.util.*;

public class UserBeanCl {
	//ҵ���߼� 
			private Connection ct=null;//�������ݿ��õı���
			private Statement sm=null;
			private ResultSet rs=null;
			private ResultSet rs1=null;
			private int pageCount = 0;//��ҳ�õĳ�Ա����
			private int rowCount = 0;
			private int pageSize = 10;		
			
			//��֤�û�
			public int checkUser(String u,String p){		
			//��������ѧ�ź�����
				int grade=0;
				try {		//�õ�����
					ct = new ConnDB().getConn();
					sm=ct.createStatement();		
					rs=sm.executeQuery("select passwd,grand from users where number="+u+" limit 1");
					
					
					if(rs.next()){
						String dbPasswd=rs.getString(1);
						System.out.println(dbPasswd);
						if(dbPasswd.equals(p))
							grade=rs.getInt(2);
						}	
			    }
			    catch (Exception ex) {			    	
			    	ex.printStackTrace();
			    }finally{		    	
			    	this.close();//�Ͽ����ݿ�����
			    }				    
			   return grade;					
			}
			
			//�����û�
			public boolean addUser(String number,String name,
					String passwd,String QQ,String phone,String group,String grand){   
				//���Ȳ�����û����ͬ��ѧ�ţ��з��أ�û�м�����������Ȳ�����е�ѧ����ע����������֤
				boolean b=false;
				try{
					ct=new ConnDB().getConn();
					sm=ct.createStatement();
					int a=sm.executeUpdate("insert into users values('"+number+"','"+name+"','"+passwd+"','"+QQ+"','"+phone+"','"+grand+"','"+group+"')");
					//a�����ӵļ�¼��
					if(a==1){
						b=true;
					}
				}catch(Exception e){
					e.printStackTrace();
				}finally {
					this.close();
				}
				return b;
			}
			
			//�޸��û�
			public boolean updadaUser(String number,String name,
					String passwd,String QQ,String phone,String group,String grand){   
				
				boolean b=false;
				try{
					ct=new ConnDB().getConn();
					sm=ct.createStatement();
					int a=sm.executeUpdate("update users SET number='"+number+"',name='"+name+"',passwd='"+passwd+"',"
							+ "QQ='"+QQ+"',phoneNum='"+phone+"',xiaozu='"+group+"',grand='"+grand+"' where number='"+number+"'");		
					//a���޸ĵļ�¼��
					if(a==1){
						b=true;
					}
				}catch(Exception e){
					e.printStackTrace();
				}finally {
					this.close();
				}
				return b;
			}
			public boolean passwdUpdate(String number,String passwd){   
				
				boolean b=false;
				try{
					ct=new ConnDB().getConn();
					sm=ct.createStatement();
					int a=sm.executeUpdate("update users SET passwd='"+passwd+"' where number='"+number+"'");		
					//a���޸ĵļ�¼��
					if(a==1){
						b=true;
					}
				}catch(Exception e){
					e.printStackTrace();
				}finally {
					this.close();
				}
				return b;
			}
			//ɾ���û�
			public boolean delUserById(String id){   
				boolean b=false;
				try{
					ct=new ConnDB().getConn();
					sm=ct.createStatement();
					int a=sm.executeUpdate("delete from users where number='"+id+"'");
					//a��ɾ���ļ�¼��
					if(a==1){
						b=true;
					}
				}catch(Exception e){
					e.printStackTrace();
				}finally {
					this.close();
				}
				return b;
			}
			
			//����pageCount;			
			public int getPageCount(){
				return pageCount;
			}
			//��ҳ��ʾ
			public ArrayList<UserBean> getUsersByPage(int pageNow) {
				ArrayList<UserBean> al = new ArrayList<UserBean>();
				try {
					ct = new ConnDB().getConn();
					sm = ct.createStatement();
					
					rs1 = sm.executeQuery("select count(*) from users");//����pageCount
					if (rs1.next()) {
						rowCount = rs1.getInt(1);
					}
					if (rowCount % pageSize == 0) {
						pageCount = rowCount / pageSize;
					} else {
						pageCount = rowCount / pageSize + 1;
					}
					
					
					rs = sm.executeQuery("select  * from users limit "  + pageSize * (pageNow - 1)+" , "+pageSize * pageNow+";");
					while (rs.next()) {
						UserBean ub = new UserBean();
						ub.setUserId(rs.getInt(1));
						ub.setUserName(rs.getString(2));
						ub.setPasswd(rs.getString(3));
						ub.setQQ(rs.getString(4));
						ub.setPhone(rs.getString(5));
						ub.setGrade(rs.getInt(6));
						ub.setGroup(rs.getString(7));
						al.add(ub); // ��al�ŵ�arrayList��
					}

				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					this.close();
				}
				return al;
			}
			
			//�����û�
			public ArrayList<UserBean> seek(String select,int pageNow) {//��һ�������ǲ�ѯ�������ڶ����Ƿ�ҳ�����
				ArrayList<UserBean> al = new ArrayList<UserBean>();
				try {
					ct = new ConnDB().getConn();
					sm = ct.createStatement();
					//rs = sm.executeQuery("select count(*) from users where group1=������");//����pageCount"   "+a+"
					rs1 = sm.executeQuery("select count(*) from users where "+select+"");
					if (rs1.next()) {
						rowCount = rs1.getInt(1);
					}
					//System.out.println(rowCount);
					if (rowCount % pageSize == 0) {
						pageCount = rowCount / pageSize;
					} else {
						pageCount = rowCount / pageSize + 1;
					}
					//System.out.println(a);
					rs = sm.executeQuery("select * from users where "+select+"  limit "  + pageSize * (pageNow - 1)+","+pageSize * pageNow+";");
					while (rs.next()) {
						UserBean ub = new UserBean();
						ub.setUserId(rs.getInt(1));
						ub.setUserName(rs.getString(2));
						ub.setPasswd(rs.getString(3));
						ub.setQQ(rs.getString(4));
						ub.setPhone(rs.getString(5));
						ub.setGrade(rs.getInt(6));
						ub.setGroup(rs.getString(7));
						al.add(ub); // ��al�ŵ�arrayList��
					}
					//System.out.println("UserCl");

				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					this.close();
				}
				return al;
			}
			//�ر���Դ
			public void close(){
				
				try {
					
					if(rs!=null){
						rs.close();
						rs=null;
					}
					if(rs1!=null){
						rs1.close();
						rs1=null;
					}
					if(sm!=null){
						sm.close();
						sm=null;
					}
					if(ct!=null){
						ct.close();
						ct=null;
					}
			    }
			    catch (Exception ex) {
			    	
			    	ex.printStackTrace();
			    }
			}

		
}

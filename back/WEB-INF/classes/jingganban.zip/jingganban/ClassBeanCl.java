package jingganban;

import java.sql.*;
import java.util.*;

public class ClassBeanCl {
	private Connection ct=null;//�������ݿ��õı���
	private Statement sm=null;
	private ResultSet rs=null;
	private int pageCount = 0;//��ҳ�õĳ�Ա����
	private int rowCount = 0;
	private int pageSize = 10;	
	//���ӿα�
	public boolean addClass(String number,String week,String classNum,String classCon){   	
		boolean b=false;
		try{
			ct=new ConnDB().getConn();
			sm=ct.createStatement();
			int a=sm.executeUpdate("insert into classes values('"+number+"','"+week+"','"+classNum+"','"+classCon+"')");
			//a�����ӵļ�¼��
			if(a==1){
				b=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			this.close();
		}
		return b;
	}
	//�޸Ŀα�
	public boolean updadaClass(String number,String week,String classNum,String classCon){   
		
		boolean b=false;
		try{
			ct=new ConnDB().getConn();
			sm=ct.createStatement();
			int a=sm.executeUpdate("update classes SET classCon='"+classCon+"' where number='"+number+"'and week='"+week+"' and classNum='"+classNum+"'");	
			//a���޸ĵļ�¼��
			if(a==1){
				b=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			this.close();
		}
		return b;
	}
	//���ҿα�
	//����ѧ�Ų�ѯ
	public ArrayList<ClassBean> seek(String number) {
		ArrayList<ClassBean> al = new ArrayList<ClassBean>();
		try {
			ct = new ConnDB().getConn();
			sm = ct.createStatement();
			rs = sm.executeQuery("select  * from classes where number="+number+"");
			while (rs.next()) {
				ClassBean ub = new ClassBean();
				ub.setNumber(rs.getInt(1));
				ub.setWeek(rs.getString(2));
				ub.setClassNum(rs.getString(3));
				ub.setClassCon(rs.getString(4));
				al.add(ub); // ��al�ŵ�arrayList��
			}
			//System.out.println("UserCl");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.close();
		}
		return al;
	}
	
	public int getPageCount(){
		return pageCount;
	}
	//��һ�������ǲ�ѯ�������������Ƿ�ҳ�����,
	public ArrayList<ClassBean> seek(String select,int pageNow) {  
		ArrayList<ClassBean> al = new ArrayList<ClassBean>();
		try {
			ct = new ConnDB().getConn();
			sm = ct.createStatement();
			//rs = sm.executeQuery("select count(*) from classes where group1=������");//����pageCount"   "+a+"
			rs = sm.executeQuery("select count(*) from classes where "+select+"");
			if (rs.next()) {
				rowCount = rs.getInt(1);
			}
			if (rowCount % pageSize == 0) {
				pageCount = rowCount / pageSize;
			} else {
				pageCount = rowCount / pageSize + 1;
			}
			//System.out.println(a);
			rs = sm.executeQuery("select  classes.*,users.name from classes,users where classes.number=users.number and "+select+
					" limit "  + pageSize * (pageNow - 1)+" , "+pageSize * pageNow+";"); 
			while (rs.next()) {
				ClassBean ub = new ClassBean();
				if(!(rs.getString(4).equals(""))){
				ub.setNumber(rs.getInt(1));
				ub.setWeek(rs.getString(2));
				ub.setClassNum(rs.getString(3));
				ub.setClassCon(rs.getString(4));
				ub.setName(rs.getString(5));
				al.add(ub);
				} // ��al�ŵ�arrayList��
			}
			//System.out.println("UserCl");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.close();
		}
		return al;
	}
	
	
	
	
	
	
	
	
	
	
	//�ر���Դ
	public void close(){
		
		try {
			
			if(rs!=null){
				rs.close();
				rs=null;
			}
			if(sm!=null){
				sm.close();
				sm=null;
			}
			if(ct!=null){
				ct.close();
				ct=null;
			}
	    }
	    catch (Exception ex) {
	    	
	    	ex.printStackTrace();
	    }
	}
}

package jingganban;

public class ClassBean {
	private int number;
	private  String week;
	private  String classNum;
	private  String classCon;
	private  String name;
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getWeek() {
		return week;
	}
	public void setWeek(String week) {
		this.week = week;
	}
	public String getClassNum() {
		return classNum;
	}
	public void setClassNum(String classNum) {
		this.classNum = classNum;
	}
	public String getClassCon() {
		return classCon;
	}
	public void setClassCon(String classCon) {
		this.classCon = classCon;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

package jingganban;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.org.apache.xpath.internal.operations.Bool;

@SuppressWarnings("serial")
public class ClassCl extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String flag=req.getParameter("flag");
		if(flag.equals("addClass")){				//���ӿα�
			HttpSession session=req.getSession();
			String u=(String)session.getAttribute("number");
			//System.out.println(u);
			String classCon[][]=new String[5][7];
			for(int i=0;i<5;i++){
			classCon[i][0]=new String(req.getParameter("one"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][1]=new String(req.getParameter("two"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][2]=new String(req.getParameter("three"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][3]=new String(req.getParameter("four"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][4]=new String(req.getParameter("five"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][5]=new String(req.getParameter("six"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][6]=new String(req.getParameter("seven"+i+"").getBytes("iso-8859-1"),"utf-8");
			}
			//System.out.println(classCon[0][0]);
			try {
					ClassBeanCl ubc=new ClassBeanCl();
					 String []q={"����һ","���ڶ�","������","������","������","������","������"};
					 boolean a=false;
					for(int i=0;i<7;i++) {
						if(ubc.addClass(u, q[i], "��һ���ڿ�",classCon[0][i])&&ubc.addClass(u, q[i], "�����Ľڿ�",classCon[1][i])
								&&ubc.addClass(u, q[i], "�������ڿ�",classCon[2][i])&&ubc.addClass(u, q[i], "���߰˽ڿ�",classCon[3][i])
								&&ubc.addClass(u, q[i], "�ھ�ʮ�ڿ�",classCon[4][i]))
						{a=true;}
						
					}
					if(a){
						req.getRequestDispatcher("Suc.jsp").forward(req,res);//	
					}
					else{
						req.getRequestDispatcher("Err.jsp").forward(req,res);//
						}	
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					
				}
		}
		else if(flag.equals("classSeekByNum")){		//ͨ��ѧ�Ų�ѯ�α�
			String number=new String(req.getParameter("number").getBytes("iso-8859-1"),"utf-8");
			String result[][]=new String[5][7];
			int m=0,n=0;
			try {
				ClassBeanCl cbl=new ClassBeanCl();
				ArrayList<ClassBean> al=cbl.seek(number);
				  for(int i=0;i<al.size();i++){
					     ClassBean ub=(ClassBean)al.get(i);
					     switch(ub.getWeek()){
					     case "����һ":n=0;	break;
					     case "���ڶ�":n=1;	break;
					     case "������":n=2;	break;
					     case "������":n=3;	break;
					     case "������":n=4;	break;
					     case "������":n=5;	break;
					     case "������":n=6;	break;
					     }
					     switch(ub.getClassNum()){
					     case "��һ���ڿ�":m=0;	break;
					     case "�����Ľڿ�":m=1;	break;
					     case "�������ڿ�":m=2;	break;
					     case "���߰˽ڿ�":m=3;	break;
					     case "�ھ�ʮ�ڿ�":m=4;	break;
					     }
					     result[m][n]=ub.getClassCon();
					    // System.out.println(result[m][n]);
				  }
				  req.setAttribute("result", result);
				  req.getRequestDispatcher("ClassSeekShow1.jsp").forward(req,res);
			} catch (Exception e) {
				 System.out.println("ClassCl����");
				e.printStackTrace();
			}
		}//classSeekByTime
		else if(flag.equals("classSeekByTime")){		//ͨ��ʱ���ѯ
			String week=new String(req.getParameter("week").getBytes("iso-8859-1"),"utf-8");
			String classNum=new String(req.getParameter("classNum").getBytes("iso-8859-1"),"utf-8");
			String select="week= '"+week+"' and classNum='"+classNum+"'";
			String s_pageNow=req.getParameter("pageNow");
			
			try{
				int pageNow=Integer.parseInt(s_pageNow);
				ClassBeanCl cbl=new ClassBeanCl();
				ArrayList<ClassBean> al=cbl.seek(select,pageNow);
				int pageCount=cbl.getPageCount();
				req.setAttribute("result", al);
				req.setAttribute("pageCount", pageCount+"");
				req.setAttribute("pageNow",pageNow+"");
				//������תչʾ����
				req.getRequestDispatcher("ClassSeekShow2.jsp").forward(req,res);
			 
			}catch(Exception e){
			e.printStackTrace();
			}
		}
		else if(flag.equals("classUpdate")){		//�޸Ŀα�ҳ����ת����
			HttpSession session=req.getSession();
			String number=(String)session.getAttribute("number");
			String result[][]=new String[5][7];
			int m=0,n=0;
			try {
				ClassBeanCl cbl=new ClassBeanCl();
				ArrayList<ClassBean> al=cbl.seek(number);
				  for(int i=0;i<al.size();i++){
					     ClassBean ub=(ClassBean)al.get(i);
					     switch(ub.getWeek()){
					     case "����һ":n=0;	break;
					     case "���ڶ�":n=1;	break;
					     case "������":n=2;	break;
					     case "������":n=3;	break;
					     case "������":n=4;	break;
					     case "������":n=5;	break;
					     case "������":n=6;	break;
					     }
					     switch(ub.getClassNum()){
					     case "��һ���ڿ�":m=0;	break;
					     case "�����Ľڿ�":m=1;	break;
					     case "�������ڿ�":m=2;	break;
					     case "���߰˽ڿ�":m=3;	break;
					     case "�ھ�ʮ�ڿ�":m=4;	break;
					     }
					     result[m][n]=ub.getClassCon();
					    // System.out.println(result[m][n]);
				  }
				  req.setAttribute("result", result);
				  req.getRequestDispatcher("ClassUpdate.jsp").forward(req,res);
			} catch (Exception e) {
				 System.out.println("ClassCl����");
				e.printStackTrace();
			}			
		}		
		else if(flag.equals("classUpdateCl")){				//�޸Ŀα�
			HttpSession session=req.getSession();
			String u=(String)session.getAttribute("number");
			//System.out.println(u);
			String classCon[][]=new String[5][7];
			for(int i=0;i<5;i++){
			classCon[i][0]=new String(req.getParameter("one"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][1]=new String(req.getParameter("two"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][2]=new String(req.getParameter("three"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][3]=new String(req.getParameter("four"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][4]=new String(req.getParameter("five"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][5]=new String(req.getParameter("six"+i+"").getBytes("iso-8859-1"),"utf-8");
			classCon[i][6]=new String(req.getParameter("seven"+i+"").getBytes("iso-8859-1"),"utf-8");
			}
			//System.out.println(classCon[0][0]);
			try {
					ClassBeanCl ubc=new ClassBeanCl();
					 String []q={"����һ","���ڶ�","������","������","������","������","������"};
					 boolean a=false;
					for(int i=0;i<7;i++) {
						if(ubc.updadaClass(u, q[i], "��һ���ڿ�",classCon[0][i])&&ubc.updadaClass(u, q[i], "�����Ľڿ�",classCon[1][i])
								&&ubc.updadaClass(u, q[i], "�������ڿ�",classCon[2][i])&&ubc.updadaClass(u, q[i], "���߰˽ڿ�",classCon[3][i])
								&&ubc.updadaClass(u, q[i], "�ھ�ʮ�ڿ�",classCon[4][i]))
						{a=true;}
						
					}
					if(a){
						req.getRequestDispatcher("Suc.jsp").forward(req,res);//	
					}
					else{
						req.getRequestDispatcher("Err.jsp").forward(req,res);//
						}	
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					
				}
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
